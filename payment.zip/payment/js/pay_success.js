
var now_is_search = 1;
var now_is_search_city_start = 1;
var now_is_search_city_end = 1;
var now_is_search_tem = 1;
var vm2_bulk = new Vue({
	el:'#startDate',
	data:{
	
	},
	mounted:function(){
		var self = this;
		mui.plusReady(function(){
			var date = new Date();
			var seperator1 = "-";
			var year = date.getFullYear();
			var month = date.getMonth() + 1;
			var strDate = date.getDate();
			if (month >= 1 && month <= 9) {
				month = "0" + month;
			}
			if (strDate >= 0 && strDate <= 9) {
				strDate = "0" + strDate;
			}
			var currentdate = year + seperator1 + month + seperator1 + strDate;
			
			self.select_date = currentdate;
			self.set_date(new Date(currentdate));
			$('#startDate').val(currentdate);
		});
	},
	methods:{
		set_date:function(date){
			var year = date.getFullYear();
			var month = date.getMonth() + 1;
			var day = date.getDate();
			var we_ek = date.getDay();  
			var week_day = ['周日','周一','周二','周三','周四','周五','周六'];
			this.week = week_day[we_ek];
			if (month < 10) {
				month = "0" + month;
			}
			if (day < 10) {
				day = "0" + day;
			}
			this.select_date = year + "-" + month + "-" + day;
			var nowDate = month + "月" + day + '日';
			this.starttime = nowDate;
		},
	}
});

//实例化vue
var vm = new Vue({
	el: '#dataList',
	data : {
        title:'支付成功',
        txt:'支付成功！',
        pay_type:'',
        from:'',
        self_id:'',
        order_id:'',
        price:''
	},
	mounted: function(){
		var self = this;
		// 初始化页面
		mui.init();
		// self.good_number = mui.(".good_number").numbox().getValue();
		self.get_control();
		this.from = this.$route.query.from
		this.order_id = this.$route.query.order_id
		console.log(this.order_id);
		this.price = this.$route.query.price ? this.$route.query.price : this.$route.query.total_amount
		console.log(this.from);
		if (this.from == 3) {
			  this.pay_type = '货到付款'
			  this.txt = '下单成功'
			  this.title = '下单成功'
		} else if (this.from == 2) {
			  this.pay_type = '支付宝支付'
			  this.txt = '支付成功'
			  this.title = '支付成功'
		} else if (this.from == 1) {
			  this.pay_type = '微信支付'
			  this.txt = '支付成功'
			  this.title = '支付成功'
		}
		mui.plusReady(function(){
			var page = plus.webview.currentWebview();
			var from = this.from;
            var order_id = this.order_id;
			
		});
		
		// mui(".good_number").numbox().setValue(this.weight)

	},
	methods:{

	},
	filters:{
		fliterTimeStr: function(value){
			return value.substring(0,10);
		},
	},
	
})

mui.init({
	swipeBack: false
});

$('.mui-scroll-wrapper').scroll({
	indicators: true //是否显示滚动条
});



// });
// 去除遮罩
function no_marker(){
	init_mask4();
	init_mask2();
	$('.search_marker').hide();
	$('.search_marker').removeClass('data-active');
	var i = $('.nav .activecolor').attr('id');
	if (i == 'type0') {
		var obj_data= $('#search_data .mui-s-data');
	} else if (i == 'type2') {
		var obj_data= $('#search_data_bulk .mui-s-data');
	}
	if (i == 'type0' || i == 'type2') {
		obj_data.removeClass('mui-s-data-active').find('img').attr('src','../images/driver/line_down.png').css({"margin-bottom":"0px"});
	}
}

var mask = mui.createMask(function(){
	no_marker();
	return true;
});//callback为用户点击蒙版时自动执行的回调；
