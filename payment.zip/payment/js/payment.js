/**
 * =================================
 * storage.js For 赤途App
 * =================================
 * Auther: 李渊
 * description: 支付
 */

//实例化vue
var vm = new Vue({
	el: '#dataList',
	data : {
        title:'支付',
        pay_type:1,
        true_pay:'',
        moto_pay:'',
        del_money:'',
        btn_title:'确认支付',
        data:{},
        total_money:'',
        from:1,
        set_pay_type:'online'
	},
	mounted: function(){
		var self = this;
		// 初始化页面
		mui.init();
		this.set_price();
		mui.plusReady(function(){
			var page = plus.webview.currentWebview();
			self.total_money = page.total_money
			self.from = page.from
			
			
			var from = this.from;
            var order_id = this.order_id;
		});
		
		// mui(".good_number").numbox().setValue(this.weight)

	},
	methods:{
    set_price:function(){
		var self = this;
        var price = self.total_money;
        var pay_type = self.pay_type;
        var data = self.data;
          var t_price = '';
          var d_price = '';
          if (price > 10000) {
            d_price = 500;
          } else if (price > 5000) {
            d_price = 200;
          } else if (price > 1000) {
            d_price = 100;
          } else if (price > 500) {
            d_price = 50;
          } else if (price > 200) {
            d_price = 20;
          } else {
            d_price = 0;
          }
        if (pay_type == 1 || pay_type == 2) {
          t_price = price - 0 - d_price;
          self.set_pay_type = 'online'
          // data.total_money = 0.01
        } else if (pay_type == 3) {
          t_price = price;
          self.set_pay_type = 'offline'
          data.total_money = price
        }
        self.true_pay = t_price;
        self.del_money = d_price;
        data.pay_type = self.set_pay_type;
        // data.total_money = this.true_pay;
        
        self.data = data;
      },
	 click_pay:function(data){
	  this.pay_type = data;
	  this.set_price();
	 },
	 onAdd:function(){
		 
	 }
	},
	filters:{
		fliterTimeStr: function(value){
			return value.substring(0,10);
		},
	},
	
})

;(function($,window,document,req){
	var _options = {
		yuPaymentURL : req.ServerUrl+req.yuPayURL, // 余额支付接口
		xinPaymentURL : req.ServerUrl+req.balancePayURL, // 信用额度
		alipayPaymentURL: req.ServerUrl+req.app_pay_vehical_alipay, // 支付宝支付接口 整车、零担
		wxPaymentURL: req.ServerUrl+req.app_pay_vehical_wechat, // 微信支付 整车、零担
		alipayPaymentURL_line: req.ServerUrl+req.pay_bulk_alipay, // 支付宝支付接口 干线下单支付
		wxPaymentURL_line: req.ServerUrl+req.pay_bulk_wechat, // 微信支付接口 干线下单支付
		alipayChannel: null, // 支付宝通道
		wxpayChannel: null, // 微信支付通道
	}
	/**
	 * @constructor payment
	 * @description 支付
	 * @param {Number} type 支付类型 1 余额支付 2 支付宝支付 3 微信支付 4 项目客户信用额度支付
	 * @param {Object} data 请求参数 
	 * @example
	 * var payment = new Payment(1,data);
	 * */
	var Payment = window.Payment = function(){}
	/**
	 * @description 获取支付通道
	 */
	Payment.prototype.getChannels = function () {
		plus.payment.getChannels( function(channels){
			for (var chanel in channels) {
		    	if(channels[chanel].id == 'alipay'){
		    		_options.alipayChannel = channels[chanel];
		    	}else if(channels[chanel].id == 'wxpay'){
		    		_options.wxpayChannel = channels[chanel];
		    	}
		    } 
		}, function(e){
			$.toast("获取支付通道列表失败："+e.message);
		});	
	}
	/**
	 * @description 请求
	 * @param {Number} type 支付方式:  1 余额支付 2 支付宝支付 3 微信支付 4 信用额度支付
	 * @param {Object} data 请求参数
	 */
	Payment.prototype.pay = function(type,ordertype,data,fun){
		var self = this;
		var PAYMENTURL = null;
		var chanel = null;
		console.log(JSON.stringify(ordertype));
		self.callback = fun;
		plus.nativeUI.showWaiting( "等待支付中..." );
		var from_ = data.from_;
		var type_from = data.type_from;
		if(typeof type != 'number'){
			type = parseInt(type);
		}
		switch (type){
			case 1: // 余额支付
				PAYMENTURL = _options.yuPaymentURL;
				break;
			case 2: // 支付宝支付
				PAYMENTURL = _options.alipayPaymentURL;
				chanel = _options.alipayChannel;
				break;
			case 3: // 微信支付
				PAYMENTURL = _options.wxPaymentURL;
				chanel = _options.wxpayChannel;
				break;
			case 4: // 信用额度支付
				PAYMENTURL = _options.xinPaymentURL;
				break;
			default:
				break;
		}
		console.log(JSON.stringify(data));
		console.log(PAYMENTURL);
		$.ajax(PAYMENTURL,{
			data:data,
//			dataType:'json',//服务器返回json格式数据
			type:'post',//HTTP请求类型
			timeout:10000,//超时时间设置为10秒；
			success:function(response){
				// console.log(JSON.stringify(response));
				plus.nativeUI.closeWaiting();//关闭旋转菊花
				if(type == 1 || type == 4){ // 余额支付或者信用额度支付
					var code = parseInt(response.code);
					var msg = response.msg;
					switch (code){
						case 400: // 参数错误
							$.toast(msg)
							break;
						case 404:
							$.toast(msg)
							openLogin();
							break;
						case 200:
							// $.toast('支付成功');
							self.callback();
							break;
						default:
							$.toast(msg)
							break;
					}
				}else{ // 支付宝或者微信支付		
		    		plus.payment.request(chanel,response,function(result){
		    			// mui.toast('支付成功');
						if(ordertype==1){    // 区分个人中心的支付还是下单的支付，1是个人中心支付，直接跳转到个人中心列表，刷新页面
							// plusCommon.popToTarget('../fullTruck/vehicleOrder.html', true);
							var list = plus.webview.currentWebview().opener();
							mui.fire(list, 'refresh');	
							mui.back();
						}else{             // 其他的支付，就要跳转到下单成功的页面。
							mui.openWindow({
								url: "../common/ssued_successful.html",
								id: "../common/ssued_successful.html",
								extras:{
									ordertype:ordertype,   // 支付类型，用于跳转下单后列表跳转
									from_:from_,
									type_from:type_from,
									datatopay:localStorage.pay_id
								}
							});
						}
						
		    			// self.callback();
		            },function(error){
		               	mui.toast('你已经取消了支付');
						// document.getElementById('paymentone').style.display='block';
		            });
				}
			},
			error:function(xhr,type,errorThrown){
				console.log(JSON.stringify(xhr));
				console.log(JSON.stringify(type));
				console.log(JSON.stringify(errorThrown));
				mui.toast('支付失败!');
	    		plus.nativeUI.closeWaiting();//关闭旋转菊花
			}
		});
	}

	/**
	 * @description 请求
	 * @param {Number} type 支付方式:  1 余额支付 2 支付宝支付 3 微信支付 4 信用额度支付
	 * @param {Object} data 请求参数
	 */
	Payment.prototype.pay_bulk = function(type,ordertype,data,fun){
		var self = this;
		var PAYMENTURL = null;
		var chanel = null;
		console.log(JSON.stringify(ordertype));
		self.callback = fun;
		plus.nativeUI.showWaiting( "等待支付中..." );
		var from_ = data.from_;
		var type_from = data.type_from;
		if(typeof type != 'number'){
			type = parseInt(type);
		}
		switch (type){
			case 1: // 余额支付
				PAYMENTURL = _options.yuPaymentURL;
				break;
			case 2: // 支付宝支付
				PAYMENTURL = _options.alipayPaymentURL_line;
				chanel = _options.alipayChannel;
				break;
			case 3: // 微信支付
				PAYMENTURL = _options.wxPaymentURL_line;
				chanel = _options.wxpayChannel;
				break;
			case 4: // 信用额度支付
				PAYMENTURL = _options.xinPaymentURL;
				break;
			default:
				break;
		}
		console.log(JSON.stringify(data));
		console.log(PAYMENTURL);
		$.ajax(PAYMENTURL,{
			data:data,
//			dataType:'json',//服务器返回json格式数据
			type:'post',//HTTP请求类型
			timeout:10000,//超时时间设置为10秒；
			success:function(response){
				// console.log(JSON.stringify(response));
				plus.nativeUI.closeWaiting();//关闭旋转菊花
				if(type == 1 || type == 4){ // 余额支付或者信用额度支付
					var code = parseInt(response.code);
					var msg = response.msg;
					switch (code){
						case 400: // 参数错误
							$.toast(msg)
							break;
						case 404:
							$.toast(msg)
							openLogin();
							break;
						case 200:
							// $.toast('支付成功');
							self.callback();
							break;
						default:
							$.toast(msg)
							break;
					}
				}else{ // 支付宝或者微信支付		
		    		plus.payment.request(chanel,response,function(result){
		    			// mui.toast('支付成功');
						if(ordertype==1){    // 区分个人中心的支付还是下单的支付，1是个人中心支付，直接跳转到个人中心列表，刷新页面
							// plusCommon.popToTarget('../fullTruck/vehicleOrder.html', true);
							var list = plus.webview.currentWebview().opener();
							mui.fire(list, 'refresh');	
							mui.back();
						}else{             // 其他的支付，就要跳转到下单成功的页面。
							mui.openWindow({
								url: "../common/ssued_successful.html",
								id: "../common/ssued_successful.html",
								extras:{
									ordertype:ordertype,   // 支付类型，用于跳转下单后列表跳转
									from_:from_,
									type_from:type_from,
								}
							});
						}
						
		    			// self.callback();
		            },function(error){
		               	mui.toast('你已经取消了支付');
						// document.getElementById('paymentone').style.display='block';
		            });
				}
			},
			error:function(xhr,type,errorThrown){
				console.log(JSON.stringify(xhr));
				console.log(JSON.stringify(type));
				console.log(JSON.stringify(errorThrown));
				mui.toast('支付失败!');
	    		plus.nativeUI.closeWaiting();//关闭旋转菊花
			}
		});
	}
	/**
	 * @description: 初始化
	 */
	Payment.prototype.Init = function(){
		var self = this;
		if(window.plus){
			self.getChannels();
		}else{
			document.addEventListener('plusready', function(){
				self.getChannels();
			}, false);
		}
	}
	
})(mui,window,document,request);
var  payment = new Payment();
payment.Init();

